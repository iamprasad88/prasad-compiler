Project done by : Prasad Thondamuthur Vasanth
Poly Id: 0529494
NID: N122926821
net Id: ptv205

Project and all modifications can be found at github: https://github.com/iamprasad88/prasad-compiler


main class is located at com.prasad.cs6413.Compiler.java;

To run the file please use
~\prasad-compiler\bin\com\prasad\cs6413\Compiler.class

Please use test.txt and modify to test the program. You may add more complex structure.