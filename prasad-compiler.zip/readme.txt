Project done by : Prasad Thondamuthur Vasanth
Poly Id: 0529494
NID: N122926821
net Id: ptv205

Project and all modifications can be found at github: https://github.com/iamprasad88/prasad-compiler


main class is located at com.prasad.cs6413.Compiler.java;

To run the file please use
~\prasad-compiler\bin\com\prasad\cs6413\Compiler.class

Please note: We use java collection hash table to simplify hash table functions.

Please note: that I have used object oriented structure for designing my Tokens.
While building tokens into arraylist(instead of hash), I store all information about the token in the token object. This array of token objects hass all info, including values from symbol table, matched values etc..., so this is an attribute table. 


Please use test.txt and modify to test the program. You may add more complex structure.